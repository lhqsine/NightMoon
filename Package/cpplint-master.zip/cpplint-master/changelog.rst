Changelog
---------

0.0.5
-----

Maintenance release, undoes earlier project folder structure changes
to remain as true to upstream as possible.

0.0.4
-----

- Merged with upstream revision r141 (2014-12-04)
This includes many new checks, see commit messages for details.
This also reverts some renaming of files, to stay close to the original project.


0.0.3
-----

- py3k compatibility

0.0.2
-----

- fixed and extended allowed extensions

0.0.1
-----

- import from googlecode, added setup.py
- imported revision r83 (2012-05-11)
